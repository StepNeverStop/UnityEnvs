﻿using UnityEngine;
using Crest;
using System.Linq;

// CREST

/// <summary>
/// Class for retrieving water height at position.
/// Attach this script to your water system and set object's tag to "Water".
/// </summary>
public class WaterInterface : MonoBehaviour
{
    private Vector3 position = Vector3.zero;
    private float height;

    public float GetWaterHeightAtLocation(float x, float z)
    {
        position.x = x;
        position.y = 0;
        position.z = z;

        height = 0f;
        OceanRenderer.Instance.CollisionProvider.SampleHeight(ref position, ref height);

        return height;
    }
}
