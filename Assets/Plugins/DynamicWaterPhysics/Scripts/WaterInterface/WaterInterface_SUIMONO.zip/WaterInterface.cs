﻿// Thanks to Stefan-Lubenberger from Unity forums for providing this script.

using UnityEngine;
using Suimono.Core;

/// <summary>
/// Version for Suimono
/// </summary>
public class WaterInterface : MonoBehaviour
{
    public SuimonoModule Suimono;

    /// <summary>
    /// Return water height y in world coordinates at world point x, z
    /// </summary>
    public float GetWaterHeightAtLocation(float x, float z)
    {
        return Suimono.SuimonoGetHeight(new Vector3(x, 0, z), "height"); ;
    }
}