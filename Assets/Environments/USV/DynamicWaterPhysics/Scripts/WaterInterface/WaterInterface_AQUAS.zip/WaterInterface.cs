﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AQUAS;

public class WaterInterface : MonoBehaviour
{
    // Aquas is flat so height of the AQUAS object can be returned as water height.
    public float GetWaterHeightAtLocation(float x, float z)
    {
        return transform.position.y;
    }
}
