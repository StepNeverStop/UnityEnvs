﻿// Thanks to DCrosby from Unity forums for providing this script.

using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UltimateWater;
/// <summary>
/// Attach this script to your non-flat water system.
/// </summary>
public class WaterInterface : MonoBehaviour
{
    // Replace "WaterSystem" with your type.
    public Water myWaterSystem;
    private WaterSample waterSample;
    private Vector3 currentWaterLevel;
    private Vector3 currentWaterForces;
    public float waterHeight;
    private void Start()
    {
        // Ultimate Water System
        myWaterSystem = GetComponent<Water>();
        waterSample = new WaterSample(myWaterSystem, WaterSample.DisplacementMode.HeightAndForces, 1.0f);
        // Hack to let Ultimate Water Wake Up, otherwise it throws an error it can't find water.
        Invoke("StartWaterSampling", 0.5f);
    }
    void StartWaterSampling()
    {
        waterSample.Start(Vector3.zero);
    }
    /// <summary>
    /// Return water height y in world coordinates at world point x, z
    /// </summary>
    public float GetWaterHeightAtLocation(float x, float z)
    {
        waterSample.GetAndResetFast(x, z, myWaterSystem.Time, ref currentWaterLevel, ref currentWaterForces);
        waterHeight = currentWaterLevel.y;
        // Do not forget to uncheck "Flat Water" under Additional Options of FloatingObject.
        //Debug.Log("Water : " + currentWaterLevel); // Will Slow down performance, to further speed this up make waterHeight Private
        return waterHeight;
    }
}