﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using AQUAS;

public class WaterInterface : MonoBehaviour
{
    // Since water is flat height of the water object can be returned.
    public float GetWaterHeightAtLocation(float x, float z)
    {
        return transform.position.y;
    }
}
