﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Ceto;

public class WaterInterface : MonoBehaviour
{

    public Ocean ocean;

    private void Start()
    {
        ocean = GetComponent<Ocean>();
    }

    public float GetWaterHeightAtLocation(float x, float z)
    {
        return ocean.QueryWaves(x, z);
    }
}